<header id="header">
    <div class="container">
        <a class="navbar-brand">
            <img src="{{ asset("images/logo.svg") }}" width="164" height="27" alt="">
        </a>
        <x-language></x-language>
    </div>
</header>
