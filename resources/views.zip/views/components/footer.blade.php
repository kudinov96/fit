<footer id="footer">
    <div class="container">
        <p>Fit Queen {{ date("Y") }}</p>
        <p><a href="#">{{ __('Политика конфидециальности') }}</a></p>
        <p><a href="https://gim.lv" target="_blank"><img width="17" height="17" src="{{ asset('images/gim.svg') }}" alt=""> {{ __('Разработка сайта и реклама - gim.lv') }}</a></p>
    </div>
</footer>
